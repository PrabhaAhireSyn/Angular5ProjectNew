import '@angular/core';
import '@angular/common';
import '@angular/platform-browser';
import '@angular/platform-browser-dynamic';
import '@angular/forms';
import '@angular/router';

import 'rxjs' ;

//third party
import 'jquery';
import 'bootstrap/dist/js/bootstrap';
import 'popper.js';
import 'bootstrap/dist/css/bootstrap.min.css';