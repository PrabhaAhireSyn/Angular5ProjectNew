import { Event } from "./event";

export class SynechronEvent implements Event {
    eventId: number;
    eventCode: string;
    eventName: string;
    description: string;
    startDate: Date;
    endDate: Date;
    fees: number;
    attendance: number;
    logo: string;
}