import { ModuleWithProviders } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { EventsListComponent } from "./components/events-list.component";
import { NewEventComponent } from "./components/new-event.component";
import { EventDetailsComponent } from "./components/event-details.component";

const eventsRouteConfig: Routes = [
    {
        path: '',
        component: EventsListComponent
    },
    {
        path: 'new',
        component: NewEventComponent
    },
    {
        path: ':id',
        component: EventDetailsComponent
    }
];

export const eventsRoutes:ModuleWithProviders = RouterModule.forChild(eventsRouteConfig);