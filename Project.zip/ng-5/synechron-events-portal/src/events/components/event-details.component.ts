import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';
import { ActivatedRoute } from "@angular/router";

import { SynechronEvent } from '../models/synechron-event';
import { SynechronEventsService } from '../services/synechron-events.service';

@Component({
    selector: 'event-details',
    templateUrl: '../views/event-details.component.html'
})

export class EventDetailsComponent implements OnInit {
    constructor(private _eventService: SynechronEventsService, private _currntRoute: ActivatedRoute) { }

    pageTitle: string = "Details of - ";
    eventDetails: SynechronEvent;
    ngOnInit(): void {
        let eventId: number=0;
        this._currntRoute.params.subscribe(
            params => {
                eventId = params["id"];
                this._eventService.getSingleEvent(eventId).subscribe(
                    data=>this.eventDetails = data
                );
            }
        );
    }
    // @Input("currentEvent") eventDetails: SynechronEvent;

    // @Output("onChildNotification") childNotification: EventEmitter<string> = new EventEmitter<string>();

    // onSendNotification(): void {
    //     this.childNotification.emit("Child has received the event object successfully!");
    //}
}