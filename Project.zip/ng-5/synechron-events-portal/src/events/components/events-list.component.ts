import { Component, OnInit } from '@angular/core';
import { SynechronEvent } from '../models/synechron-event';
import { SynechronEventsService } from '../services/synechron-events.service';

@Component({
    selector: 'events-list',
    templateUrl: '../views/events-list.component.html'
})

export class EventsListComponent implements OnInit {
    constructor(private _eventsService: SynechronEventsService) { 
        
    }

    ngOnInit(): void {
        //this.events = this._eventsService.getAllEvents();
        this._eventsService.getAllEvents().subscribe(
            data => this.events = data,
            error => console.log('error!'),
            () => console.log("Service call completed!")
        );
    }

    pageTitle: string="Synechron Events List!";
    subTitle: string="Published by Synechron HR Pune";
    //childMessage: string = "";
    // selectedEvent:SynechronEvent;
    // onEventSelection(event: SynechronEvent):void {
    //     this.selectedEvent = event;
    //     //console.log(this.selectedEvent);
    // }

    // onReceiveChildMessage(message: string): void {
    //     this.childMessage = message;
    // }

    events:SynechronEvent[] = [];
}