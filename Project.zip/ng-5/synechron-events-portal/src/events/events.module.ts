import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

//Components
import { EventsListComponent } from './components/events-list.component';
import { EventDetailsComponent } from './components/event-details.component';
import { NewEventComponent } from './components/new-event.component';

//Services
import { SynechronEventsService } from './services/synechron-events.service';

//Pipes
import { FilterByPipe } from './pipes/filter-by-pipe';
import { FirstLetterCapital } from './pipes/first-letter-capital.pipe';
import { RouterModule } from '@angular/router';
import { eventsRoutes } from './events.routing';

@NgModule({
    imports: [CommonModule, HttpClientModule, FormsModule, ReactiveFormsModule, RouterModule, eventsRoutes],
    exports: [EventsListComponent, NewEventComponent],
    declarations: [
        EventsListComponent,
        EventDetailsComponent,
        NewEventComponent,
        FirstLetterCapital,
        FilterByPipe
    ],
    providers: [SynechronEventsService],
})
export class EventsModule { }
