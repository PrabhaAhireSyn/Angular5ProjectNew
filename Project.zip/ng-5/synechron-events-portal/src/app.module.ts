import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";

//Router
import { appRoutes } from "./app.routing";

//Components
import { AppComponent } from "./app.component";
import { NavigationModule } from "./navigation/navigation.module";

@NgModule({
    imports: [BrowserModule, NavigationModule, appRoutes],        //importing other dependency modules, in-built/custom modules
    exports: [],        //export components as dependencies to other modules
    declarations: [AppComponent],   //Components added in module must be registered here. e.g. Components, Pipes, Directives
    providers: [],      //Custom Services [Singleton objects]
    bootstrap: [AppComponent]       //Root component which needs to be loaded while bootstraping application
})
export class AppModule {

}