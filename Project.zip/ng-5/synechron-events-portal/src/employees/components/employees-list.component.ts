import { Component } from "@angular/core";
import { SynechronEmployee } from "../models/synechron-employee";

@Component({
    selector: 'employees-list',
    templateUrl: '../views/employees-list.component.html'
})
export class EmployeesListComponent {
    pageTitle: string = "Welcome to Synechron Employees List";
    subTitle: string = "Core Development Center of Pune!";
    //employee: SynechronEmployee;
    employees: SynechronEmployee[] = [
        {
            employeeId: 1234,
            employeeName: 'Prabha AH',
            address: 'Suncity 111',
            city: 'Pune',
            country: 'India',
            platform: 'Open Source',
            skillSets: 'JS/Angular',
            email: 'prabha.ah@synechron.com',
            phone: '9876543210',
            avatar: 'images/noImage.png'
        },
        {
            employeeId: 1234,
            employeeName: 'Jaya R',
            address: 'Megapolis 123',
            city: 'Pune',
            country: 'India',
            platform: 'Open Source',
            skillSets: 'AngularJS',
            email: 'jaya.r@synechron.com',
            phone: '9886345215',
            avatar: 'images/noImage.png'
        },
        {
            employeeId: 5984,
            employeeName: 'Amol B',
            address: 'Ravet B-405',
            city: 'Pune',
            country: 'India',
            platform: 'Open Source',
            skillSets: 'JS, Angular',
            email: 'amol.b@synechron.com',
            phone: '4567891238',
            avatar: 'images/noImage.png'
        }
    ];

    constructor() {
        // this.employee = new SynechronEmployee;
        // this.employee.employeeId = 1234;
        // this.employee.employeeName = 'Test Emp';
        // this.employee.address = 'Suncity 111';
        // this.employee.city = 'Pune';
        // this.employee.country = 'India';
        // this.employee.platform = 'Open Source';
        // this.employee.skillSets = 'JS/Angular';
        // this.employee.email = 'prabha.ah@synechron.com';
        // this.employee.phone = '9876543210';
        // this.employee.avatar = '';
    }

    selectedEmployee: SynechronEmployee;
    onSelectEmployee(employee: SynechronEmployee): void {
        this.selectedEmployee = employee;
        //console.log(this.selectedEmployee);
    }
}