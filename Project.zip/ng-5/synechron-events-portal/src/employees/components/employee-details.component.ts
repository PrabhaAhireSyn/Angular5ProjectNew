import { Component, Input } from '@angular/core';
import { SynechronEmployee } from '../models/synechron-employee';

@Component({
    selector: 'employee-details',
    templateUrl: '../views/employee-details.component.html'
})

export class EmployeeDetailsComponent {
    constructor() { }
    pageTitle: string = "Details of - ";

    @Input("currentEmployee") employeeDetails: SynechronEmployee;
}