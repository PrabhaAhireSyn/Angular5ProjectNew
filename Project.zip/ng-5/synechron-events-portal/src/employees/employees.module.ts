import { NgModule } from '@angular/core';
import { CommonModule } from "@angular/common";
import { EmployeesListComponent } from './components/employees-list.component';
import { employeesRoutes } from './employees.routing';

@NgModule({
    imports: [CommonModule, employeesRoutes],
    exports: [],
    declarations: [EmployeesListComponent],
    providers: []
})
export class EmployeesModule { }
