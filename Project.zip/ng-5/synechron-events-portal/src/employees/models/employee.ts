export interface Employee {
    employeeId: number;
    employeeName:string;
    address: string;
    city: string;
    country: string;
    platform: string;
    skillSets: string;
    email: string;
    phone: string;
    avatar: string;
}