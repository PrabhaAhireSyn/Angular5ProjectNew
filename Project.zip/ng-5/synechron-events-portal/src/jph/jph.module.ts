import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { JphPostsListComponent } from './components/jph-posts-list.component';
import { JphService } from './services/jph.service';
import { jphRoutes } from './jph.routing';

@NgModule({
    imports: [CommonModule, HttpClientModule, jphRoutes],
    exports: [JphPostsListComponent],
    declarations: [JphPostsListComponent],
    providers: [JphService]
})
export class JphModule { }
