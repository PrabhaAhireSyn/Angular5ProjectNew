import { Component } from '@angular/core';

@Component({
    selector: 'sep-menu-bar',
    templateUrl: '../views/sep-menu.component.html'
})

export class SepMenuComponent {
    constructor() { }

    menuItems: string[] = [
        //"images/logo.png",
        "Synechron EP",
        "Home",
        "Employees",
        "Events",
        "Jph Posts",
        "Register Event"
    ];
}