import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'sep-home',
    template: `<h1>Welcome to Synechron Events Portal Home Page!</h1>`
})

export class SepHomeComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}