import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { SepHomeComponent } from './components/sep-home.component';
import { homeRoutes } from './home.routing';

@NgModule({
    imports: [CommonModule, homeRoutes],
    exports: [SepHomeComponent],
    declarations: [SepHomeComponent]
})
export class HomeModule { }
