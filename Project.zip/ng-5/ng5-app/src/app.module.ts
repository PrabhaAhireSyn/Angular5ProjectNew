import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";

import { AppComponent } from "./app.component";

@NgModule({
    imports: [BrowserModule],        //importing other dependency modules, in-built/custom modules
    exports: [],        //export components as dependencies to other modules
    declarations: [AppComponent],   //Components added in module must be registered here. e.g. Components, Pipes, Directives
    providers: [],      //Custom Services [Singleton objects]
    bootstrap: [AppComponent]       //Root component which needs to be loaded while bootstraping application
})
export class AppModule {

}