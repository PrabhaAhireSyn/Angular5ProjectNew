import { Component } from "@angular/core";

@Component({
    selector: 'my-app',
    template: '<h1>Hello World App!</h1>'
})
export class AppComponent {

}