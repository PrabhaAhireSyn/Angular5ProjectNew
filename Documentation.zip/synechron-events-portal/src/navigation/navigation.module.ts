import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { CommonModule } from '@angular/common';
import { SepMenuComponent } from './components/sep-menu.component';


@NgModule({
    imports: [CommonModule,RouterModule],
    exports: [SepMenuComponent],
    declarations: [SepMenuComponent]
})
export class NavigationModule { }