import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

import { SynechronEvent } from "../models/synechron-event";
import { EventForm } from "../models/event-form";

@Injectable()
export class SynechronEventsService {

    constructor(private _http: HttpClient) {

    }

    getAllEvents(): Observable<SynechronEvent[]> {
        return this._http.get<SynechronEvent[]>("http://localhost:9090/api/events");
    }
    getSingleEvents(eventId: number): Observable<SynechronEvent> {
        return this._http.get<SynechronEvent>("http://localhost:9090/api/events/" + eventId);
    }
    insertNewEvent(event: EventForm): Observable<string> {
        return this._http.post<string>("http://localhost:9090/api/events", event);
    }
    /* private eventsData: SynechronEvent[] = [
         {
             eventId: 1,
             eventCode: 'JQ3SEM',
             eventName: 'jQuery 3 - Seminar',
             description: 'Discussion on all new features of jQuery 3.x',
             startDate: new Date(),
             endDate: new Date(),
             fees: 200,
             attendance: 78,
             logo: 'images/jq3.png'
         },
         {
             eventId: 2,
             eventCode: 'NG1SEM',
             eventName: 'Angular 1.x - Seminar',
             description: 'Discussion on all new features of Angular 1.x',
             startDate: new Date(),
             endDate: new Date(),
             fees: 200,
             attendance: 68,
             logo: 'images/ng1.png'
         },
         {
             eventId: 3,
             eventCode: 'JQ3SEM',
             eventName: 'Angular 2.x - Seminar',
             description: 'Discussion on all new features of Angular 2.x',
             startDate: new Date(),
             endDate: new Date(),
             fees: 200,
             attendance: 88,
             logo: 'images/ng2.png'
         },
         {
             eventId: 4,
             eventCode: 'NG4SEM',
             eventName: 'Angular 4.x - Seminar',
             description: 'Discussion on all new features of Angular 4.x',
             startDate: new Date(),
             endDate: new Date(),
             fees: 200,
             attendance: 28,
             logo: 'images/ng2.png'
         },
         {
             eventId: 5,
             eventCode: 'BT3SEM',
             eventName: 'Bootstrap CSS 3 - Seminar',
             description: 'Discussion on all new features of Bootstrap CSS 3',
             startDate: new Date(),
             endDate: new Date(),
             fees: 200,
             attendance: 56,
             logo: 'images/bs3.png'
         }
     ];*/
}