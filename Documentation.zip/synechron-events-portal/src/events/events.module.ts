import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { eventsRoutes } from './events.routing';

import { EventsListComponent } from './components/events-list.component';
import { EventDetailsComponent } from './components/event-details.component';
import { NewEventComponent } from './components/new-event.component';
import { FirstLetterCapital } from './pipes/first-letter-captial.pipe';
import { FilterByPipe } from './pipes/filter-by.pipe';
import { SynechronEventsService } from './services/synechron-events.service';




@NgModule({
    imports: [CommonModule, HttpClientModule, FormsModule, ReactiveFormsModule,RouterModule, eventsRoutes],
    exports: [
        EventsListComponent,
        NewEventComponent
    ],
    declarations: [
        EventsListComponent,
        EventDetailsComponent,
        NewEventComponent,
        FirstLetterCapital,
        FilterByPipe
    ],
    providers: [SynechronEventsService],
})
export class EventsModule { }
