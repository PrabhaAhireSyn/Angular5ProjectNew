import { FormGroup, FormControl, Validators } from "@angular/forms";

export class EventForm {
    eventForm: FormGroup = new FormGroup({
        eventId: new FormControl('0', Validators.required),
        eventCode: new FormControl('FAKEID', [Validators.required, Validators.maxLength(6)]),
        eventName: new FormControl('No Event', Validators.required),
        description: new FormControl(),
        startDate: new FormControl(),
        endDate: new FormControl(),
        fees: new FormControl(),
        attendance: new FormControl(0, [Validators.required, Validators.max(100), Validators.min(0)]),
        logo: new FormControl("images/noimage.png")
    })
}