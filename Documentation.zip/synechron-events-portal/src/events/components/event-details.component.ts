import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from "@angular/router";

import { SynechronEvent } from '../models/synechron-event';
import { SynechronEventsService } from '../services/synechron-events.service';

@Component({
    selector: 'event-details',
    templateUrl: '../views/event-details.component.html'
})
export class EventDetailsComponent implements OnInit {
    constructor(private _eventsService: SynechronEventsService, private _currentRoute: ActivatedRoute) { }
    pageTitle: string = "Details of - ";
    eventDetails: SynechronEvent;
    ngOnInit(): void {
        let eventId: number = 0;
        this._currentRoute.params.subscribe(
            params => {
                eventId = params["id"];
                this._eventsService.getSingleEvents(eventId).subscribe(
                    data => this.eventDetails = data
                );
            }
        );

    }
    //@Input("currentEvent") eventDetails: SynechronEvent;

    // @Output("onChildNotification") childNotification: EventEmitter<string> = new EventEmitter<string>();

    // onSendNotification(): void {
    //     this.childNotification.emit("Child has received the event object successfully!");
    // }
}