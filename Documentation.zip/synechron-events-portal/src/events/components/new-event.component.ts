import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";

import { EventForm } from "../models/event-form";
import { SynechronEventsService } from '../services/synechron-events.service';

@Component({
    selector: 'new-event',
    templateUrl: '../views/new-event.component.html',
    styles: [
        'input.ng-invalid { border-left : 3px solid red; } input.ng-valid { border-left : 3px solid green; }'
    ]
})

export class NewEventComponent implements OnInit {
    constructor(private _eventsService: SynechronEventsService, private _router: Router) {

    }
    newEvent: EventForm = new EventForm();
    ngOnInit() { }
    onEventFormSubmit(): void {
        this._eventsService.insertNewEvent(this.newEvent.eventForm.value).subscribe(
            data => this._router.navigateByUrl("/events"),
            err => console.log(err),
            () => console.log("Service call completed!")
        );
    }
}