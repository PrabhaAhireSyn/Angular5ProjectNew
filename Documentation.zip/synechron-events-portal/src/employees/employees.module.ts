import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { employeesRoutes } from './employees.routing';

import { EmployeesListComponent } from './components/employees-list.component';



@NgModule({
    imports: [CommonModule, employeesRoutes],
    exports: [],
    declarations: [EmployeesListComponent],
    providers: [],
})
export class EmployeesModule { }
