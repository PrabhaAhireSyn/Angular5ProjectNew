import { Component } from "@angular/core";

import { SynechronEmployee } from "../models/synechron-employee";

@Component({
    selector: 'employees-list',
    templateUrl: '../views/employees-list.component.html'
})
export class EmployeesListComponent {
    constructor() {
        // this.employee = new SynechronEmployee();
        // this.employee.employeeId = 2389;
        // this.employee.employeeName = "Pravinkumar R. D.";
        // this.employee.address = "Suncity A8/404";
        // this.employee.city = "Pune";
        // this.employee.country = "India";
        // this.employee.email = "pravinkumar.r.d@synechron.com";
        // this.employee.phone = "+91 23892838";
        // this.employee.platform = "Microsoft/Open Source";
        // this.employee.skillSets = "MS/JS";
    }

    pageTitle: string = "Welcome To Synechron Employees List";
    subTitle: string = "Core Development Centre of Pune!";
    //employee: SynechronEmployee;
    employees: SynechronEmployee[] = [
        {
            employeeId: 2379,
            employeeName: "Pravinkumar R. D.",
            address: "Suncity, A8/404",
            city: "Pune",
            email: "pravinkumar@synechron.com",
            phone: "+91 23232332",
            country: "India",
            platform: "Microsoft, Open Source",
            skillSets: "MS, JS",
            avatar: "images/noimage.png"
        },
        {
            employeeId: 2380,
            employeeName: "Manish Sharma",
            address: "MoonCity, J8/3489",
            city: "Pune",
            email: "manish@synechron.com",
            phone: "+91 22222222",
            country: "India",
            platform: "Microsoft, Open Source",
            skillSets: "MS, JS",
            avatar: "images/noimage.png"
        },
        {
            employeeId: 2381,
            employeeName: "Alisha C.",
            address: "Greencity, A8/404",
            city: "Mumbai",
            email: "alisha@synechron.com",
            phone: "+91 55665566",
            country: "India",
            platform: "Microsoft",
            skillSets: "MS",
            avatar: "images/noimage.png"
        }
    ];
}