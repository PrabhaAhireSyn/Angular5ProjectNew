import { ModuleWithProviders } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

import { EmployeesListComponent } from "./components/employees-list.component";


const employeesRouteConfig: Routes = [
    {
        path: "",
        component: EmployeesListComponent
    }
];

export const employeesRoutes: ModuleWithProviders = RouterModule.forChild(employeesRouteConfig);