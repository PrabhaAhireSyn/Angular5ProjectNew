import { ModuleWithProviders } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";

const defaultRoute: Routes = [
    {
        path: '',
        loadChildren: './home/home.module#HomeModule'
    }
];
const homeRoute: Routes = [
    {
        path: 'home',
        loadChildren: './home/home.module#HomeModule'
    }
];
const employeeRoute: Routes = [
    {
        path: 'employees',
        loadChildren: './employees/employees.module#EmployeesModule'
    }
];
const eventRoute: Routes = [
    {
        path: 'events',
        loadChildren: './events/events.module#EventsModule'
    }
];
const jphRoute: Routes = [
    {
        path: 'jph',
        loadChildren: './jph/jph.module#JphModule'
    }
];

const appRoutesConfig: Routes = [
    ...homeRoute,
    ...employeeRoute,
    ...eventRoute,
    ...jphRoute,
    ...defaultRoute
];


export const appRoutes: ModuleWithProviders = RouterModule.forRoot(appRoutesConfig);