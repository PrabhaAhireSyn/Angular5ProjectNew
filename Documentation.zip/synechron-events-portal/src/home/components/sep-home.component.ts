import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'sep-home',
    template: `<h1>Welcome To Synechron Events Portal Home Page!`
})

export class SepHomeComponent implements OnInit {
    constructor() { }

    ngOnInit() { }
}