import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { homeRoutes } from './home.routing';

import { SepHomeComponent } from './components/sep-home.component';


@NgModule({
    imports: [CommonModule, homeRoutes],
    exports: [SepHomeComponent],
    declarations: [SepHomeComponent],
    providers: [],
})
export class HomeModule{ }