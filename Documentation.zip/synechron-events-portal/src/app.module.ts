import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";

import { appRoutes } from "./app.routing";

import { AppComponent } from "./app.component";
import { NavigationModule } from "./navigation/navigation.module";



@NgModule({
    imports: [BrowserModule, NavigationModule, appRoutes],//In-built Modules or custom modules
    exports: [],
    declarations: [
        AppComponent
    ],//Components, Pipes, Directives
    providers: [],//Custom Services [Singletone Objects]
    bootstrap: [AppComponent]//Root Component
})
export class AppModule {

}