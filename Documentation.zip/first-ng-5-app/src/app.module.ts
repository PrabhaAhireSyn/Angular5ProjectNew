import { NgModule } from "@angular/core";
import { BrowserModule } from "@angular/platform-browser";


import { AppComponent } from "./app.component";

@NgModule({
    imports: [BrowserModule],//In-built Modules or custom modules
    exports: [],
    declarations: [AppComponent],//Components, Pipes, Directives
    providers: [],//Custom Services [Singletone Objects]
    bootstrap: [AppComponent]//Root Component
})
export class AppModule {

}