import { Component } from "@angular/core";

@Component({
    selector:'my-app',
    template:'<h1>Welcome To Synechron Pvr. Ltd.</h1>'
})
export class AppComponent{

}